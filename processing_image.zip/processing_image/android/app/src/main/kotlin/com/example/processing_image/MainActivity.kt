package com.example.processing_image

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
