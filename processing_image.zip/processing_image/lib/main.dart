import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(MaterialApp(
    home: HomeScreen(),
));

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();

}

class _HomeScreenState extends State<HomeScreen> {
  File pickedImage;
  bool isImageLoaded = false;

  getImageFromGallery() async {
    var tempStore = await ImagePicker().getImage(source: ImageSource.gallery);

    setState(() {
      pickedImage = File(tempStore.path);
      isImageLoaded = true;
    });
  }


  @override
  Widget build(BuildContext context) {
   return Scaffold(
     appBar:AppBar(
       title: Text("TFLite Mathew's Page"),
     ),
     body: Container(
       child:Column(
         children:[
           SizedBox(height: 30),
           isImageLoaded
           ? Center(
             child: Container(
               height: 350,
               width: 350,
               decoration: BoxDecoration(
                 image: DecorationImage(
                   image:FileImage(File(pickedImage.path)),
                   fit: BoxFit.contain))
                 ),
               )
               : Container()
         ],
       ),
     ),
     floatingActionButton: FloatingActionButton(
       onPressed: (){
         getImageFromGallery();
       },
       child: Icon(Icons.photo_album),
     ),
   );
  }
}

